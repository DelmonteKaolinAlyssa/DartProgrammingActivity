import 'dart:io';

void main() {
	var number = 1;
  double LD = 45.75;
  double UL = 43.18;
  double DL = 37.12;
  double BD = 48.03;
  var total;
  print("Choose: ");
  print("1. Cash");
  print("2. Liter");
  var choose = int.parse(stdin.readLineSync());
  if (number == choose) {
    print("You choose the Cash\n");}
  else {
    print("You choose the Liter\n");}
    print("Type of fuel?");
    print("1. Leaded");
    print("2. Unleaded");
    print("3. Diesel");
    print("4. Bio-Diesel");

    var fuel = int.parse(stdin.readLineSync());
    if (fuel == 1) {
      print("Price of Leaded fuel: 45.75");}
    else if (fuel == 2) {
      print("Price of Unleaded fuel: 43.18");}
    else if (fuel == 3) {
      print("Price of Diesel fuel: 37.12");}
    else if (fuel == 4){
      print("Price of Bio-diesel fuel: 48.03");}
    else {
      print("Unavailable");}

    print("How many liters?");
    var LR = int.parse(stdin.readLineSync());

    print("How much money do you have?");
    var MY = int.parse(stdin.readLineSync());

    if (fuel == 1) {
      var total_LD = LD * LR;
      print("$LR Liter");
      print("Total: $total_LD");
      if (total_LD > MY) {
        print("Your money is not enough");}
      var CE = MY - total_LD;
      print("Your Change: $CE");}
    else if (fuel == 2) {
      var total_UL = UL * LR;
      print("$LR Liters");
      print("Total Amount: $total_UL");
      if (total_UL > MY) {
        print("Your money is not enough");}
      var CE_UL = MY - total_UL;
      print("Your Change: $CE_UL");}
    else if (fuel == 3) {
      var total_DL = DL * LR;
      print("LR Liters");
      print("Total Amount: $total_DL");
      if (total_DL > MY) {
        print("Your money is not enough");}
      var CE_DL = MY - total_DL;
      print("Your Change: $CE_DL");}
    else if (fuel == 4) {
      var total_BD = BD * LR;
      print("$LR Liters");
      print("Total Amount: $total_BD");
      if (total_BD > MY) {
        print("Your money is not enough");}
      var CE_BD = MY - total_BD;
      print("Change: $CE_BD");}
    else {
      print("Unvailable");} 

}