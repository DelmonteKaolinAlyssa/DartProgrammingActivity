import 'dart:io';
bool checkFibbo(List<int> listFibbo) {
  for (int i = 2; i<listFibbo.length; i++)
  { if((listFibbo[i - 1] + listFibbo[i - 2]) != listFibbo[i])
    {return false;}
  }
  return true;
  }

void main() {
	print('Checking Fibbonacci\n');

  List<int> listFibbo = new List();
  print("Enter the size of the list (Note: The size should be greater than 3 or less than 10):");

  int size = int.parse(stdin.readLineSync());

  if(size < 3 || size > 10) {
    print("Invalid number size");
    }
    else {
      for(int i = 0; i < size; i++){
        int a = i+1;
        print("Enter the numbers $a: ");
        
        listFibbo.add(int.parse(stdin.readLineSync()));
        }
        print(listFibbo);
        print(checkFibbo(listFibbo));
        }
}